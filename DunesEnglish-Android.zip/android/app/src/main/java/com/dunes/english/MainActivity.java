package com.dunes.english;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import java.util.LinkedList;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.speech.tts.Voice;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.content.pm.PackageManager;
import android.Manifest;
import org.json.JSONArray;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Offline WebView shell + native Text-to-Speech bridge (WebView has no speechSynthesis). */
public class MainActivity extends Activity {
    private WebView web;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private SpeechRecognizer recognizer;
    private String pendingLang = null;
    private static final int REQ_MIC = 7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        web.setBackgroundColor(0xFFE9EEFD);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // progress is saved in localStorage
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }
        });

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(Locale.US);
                ttsReady = true;
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    runOnUiThread(() -> Toast.makeText(this,
                        "ثبّت بيانات الصوت الإنجليزية من إعدادات تحويل النص إلى كلام", Toast.LENGTH_LONG).show());
                }
            }
        });

        web.addJavascriptInterface(new Bridge(), "AndroidTTS");
        if (SpeechRecognizer.isRecognitionAvailable(this)) web.addJavascriptInterface(new SttBridge(), "AndroidSTT");
        web.loadUrl("file:///android_asset/index.html");
    }

    /* Per-character voices: pick an installed offline English voice by gender + index (e.g. "m2", "f0"). */
    private static final String[] MALE_CODES = {"iol", "iom", "tpd", "rjs", "gbb", "gbd", "male"};
    private boolean isMale(Voice v) {
        String n = v.getName().toLowerCase(Locale.ROOT);
        for (String c : MALE_CODES) if (n.contains(c) && !n.contains("female")) return true;
        return false;
    }
    private Voice pickVoice(Locale loc, String key) {
        try {
            if (key == null || key.length() < 2) return null;
            boolean male = key.charAt(0) == 'm';
            int idx = Integer.parseInt(key.substring(1));
            List<Voice> same = new ArrayList<>(), any = new ArrayList<>();
            for (Voice v : tts.getVoices()) {
                if (v.isNetworkConnectionRequired()) continue;
                Locale vl = v.getLocale();
                if (!"en".equals(vl.getLanguage())) continue;
                if (isMale(v) != male) continue;
                if (vl.getCountry().equals(loc.getCountry())) same.add(v); else any.add(v);
            }
            List<Voice> list = same.isEmpty() ? any : same;
            if (list.isEmpty()) return null;
            Collections.sort(list, (a, b) -> a.getName().compareTo(b.getName()));
            return list.get(idx % list.size());
        } catch (Exception e) { return null; }
    }

    /* Queue: voice, rate and pitch are global in Android TTS, so they are applied only when an
       utterance actually starts. Changing them while another line is playing cut that line off. */
    private static class Item { String t, lang, vk; float rate, pitch; Item(String t, float r, float p, String l, String v) { this.t = t; rate = r; pitch = p; lang = l; vk = v; } }
    private final LinkedList<Item> queue = new LinkedList<>();
    private boolean busy = false;
    private boolean listenerSet = false;

    private void ensureListener() {
        if (listenerSet || tts == null) return;
        listenerSet = true;
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String id) {}
            @Override public void onDone(String id) { next(); }
            @Override public void onError(String id) { next(); }
            @Override public void onStop(String id, boolean interrupted) { }
        });
    }
    private void next() {
        Item it;
        synchronized (queue) { it = queue.poll(); busy = it != null; }
        if (it != null) play(it);
    }
    private void play(Item it) {
        Locale loc = "en-GB".equals(it.lang) ? Locale.UK : Locale.US;
        Voice v = pickVoice(loc, it.vk);
        if (v != null) tts.setVoice(v); else tts.setLanguage(loc);
        tts.setSpeechRate(it.rate);
        tts.setPitch(it.pitch);
        tts.speak(it.t, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime());
    }
    private void say(String text, float rate, float pitch, String lang, String vk, boolean add) {
        if (!ttsReady || tts == null) return;
        ensureListener();
        Item it = new Item(text, rate, pitch, lang, vk);
        synchronized (queue) {
            if (add && (busy || tts.isSpeaking())) { queue.add(it); return; }
            queue.clear(); busy = true;
        }
        play(it);
    }

    private class Bridge {
        @JavascriptInterface public void speak(String t, float rate, float pitch, String lang, String vk) { say(t, rate, pitch, lang, vk, false); }
        @JavascriptInterface public void add(String t, float rate, float pitch, String lang, String vk) { say(t, rate, pitch, lang, vk, true); }
        @JavascriptInterface public void stop() { synchronized (queue) { queue.clear(); busy = false; } if (tts != null) tts.stop(); }
    }

    /* ---------- Speech recognition for the speaking exercise (prefers offline models) ---------- */
    private void js(String code) { runOnUiThread(() -> web.evaluateJavascript(code, null)); }
    private void startListening(String lang) {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingLang = lang; requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC); return;
        }
        if (tts != null) tts.stop();
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                public void onResults(Bundle b) {
                    java.util.ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    JSONArray a = new JSONArray(); if (r != null) for (String x : r) a.put(x);
                    js("window.__stt&&__stt.ok(" + JSONObjectQuote(a.toString()) + ")");
                }
                public void onError(int e) { js("window.__stt&&__stt.err('" + (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ? "perm" : e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ? "nomatch" : "fail") + "')"); }
                public void onReadyForSpeech(Bundle b) {} public void onBeginningOfSpeech() {} public void onRmsChanged(float v) {}
                public void onBufferReceived(byte[] b) {} public void onEndOfSpeech() {} public void onPartialResults(Bundle b) {} public void onEvent(int t, Bundle b) {}
            });
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 4);
        i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        recognizer.startListening(i);
    }
    private static String JSONObjectQuote(String s) { return org.json.JSONObject.quote(s); }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == REQ_MIC) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED && pendingLang != null) startListening(pendingLang);
            else js("window.__stt&&__stt.err('perm')");
            pendingLang = null;
        }
    }

    private class SttBridge {
        @JavascriptInterface public void listen(String lang) { runOnUiThread(() -> startListening(lang)); }
        @JavascriptInterface public void stop() { runOnUiThread(() -> { if (recognizer != null) recognizer.cancel(); }); }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.appBack && window.appBack()) ? 'y' : 'n'", v -> {
            if (v == null || !v.contains("y")) finish();
        });
    }

    @Override
    protected void onPause() { super.onPause(); if (tts != null) tts.stop(); }

    @Override
    protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
